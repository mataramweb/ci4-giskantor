
 <a href="<?= base_url('kantor/add'); ?>" class="btn btn-sm btn-primary">Add</a>



                                <?php 
                             if(!empty(session()->getFlashdata('success'))) { ?>
                             <div class="alert alert-success">
                                 <?php echo  session()->getFlashdata('success'); ?>
                            </div>
                               
                            <?php   }  ?>
<table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Kantor</th>
                                                <th>No Telpon</th>
                                                <th>Alamat</th>
                                                <th>Foto</th>
                                                <th>Aksioni</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no=1; foreach ($kantor as $key => $value) { ?>

                                 
                                            <tr>
                                                <td><?= $no++; ?></td>
                                                <td><?= $value['nama_kantor']; ?></td>
                                                <td><?= $value['no_telpon']; ?></td>
                                                <td><?= $value['alamat']; ?></td>
                                                <td><img src="<?= base_url('foto/' .$value['foto']); ?>" alt="" original-title="" width="55" height="55"></td>
                                                <td>
                                                    <a href="<?= base_url('kantor/edit/'.$value['id']); ?>" class="btn btn-sm btn-success">Edit</a>
                                                    <a href="<?= base_url('kantor/delete/'.$value['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah ingin hapus data ?')">Hapus</a>
                                                </td>
                                            </tr>
                                            <?php    } ?>
                                        </tbody>
                  
                                    </table>