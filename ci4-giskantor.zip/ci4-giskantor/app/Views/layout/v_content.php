
<!-- content body -->
<div class="content-body">
<div class="container">
<div class="row page-titles">
<?= $judul ?>
</div>
<div class="row">
<div class="col-lg-12">
<div class="card">
    <div class="card-body">
<?php
if ($isi)
{
    echo view($isi);
    
}

?>
    </div>
</div>
</div>

</div>


</div>
</div>
