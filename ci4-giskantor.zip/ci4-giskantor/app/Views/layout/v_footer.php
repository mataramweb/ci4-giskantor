 <!-- footer -->
 <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; <a href="https://ule.merkulov.design">Ule</a> 2019, by <a href="https://1.envato.market/tf-merkulove" target="_blank">merkulove</a></p>
            </div>
        </div>
        <!-- #/ footer -->
    </div>
    <!-- Common JS -->
    <script src="<?php echo base_url(); ?>/desain/assets/plugins/common/common.min.js"></script>
    <!-- Custom script -->
    <script src="<?php echo base_url(); ?>/desain/main/js/custom.min.js"></script>

    <!-- Common JS -->
    <script src="<?php echo base_url(); ?>/desain/assets/plugins/common/common.min.js"></script>
    <!-- Custom script -->
    <script src="<?php echo base_url(); ?>/desain/js/custom.min.js"></script>
    <script src="<?php echo base_url(); ?>/desain/assets/plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>/desain/assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>/desain/assets/plugins/tables/js/datatable-init/datatable-basic.min.js"></script>
</body>


</body>

</html>