      <!-- sidebar -->
      <div class="nk-sidebar">
            <div class="nk-nav-scroll">
                <ul class="metismenu" id="menu">
                    <li class="nav-label">Menu Utama</li>                

					<li><a href="<?= base_url('home') ?>"><i class="mdi mdi-account-multiple"></i> <span class="nav-text">Pemetaan</span></a></li>
                    <li><a href="<?= base_url('kantor') ?>"><i class="mdi mdi-information-outline"></i> <span class="nav-text">Data Kantor</span></a></li>
         





                    
                </ul>
            </div>
            <!-- #/ nk nav scroll -->
        </div>
        <!-- #/ sidebar -->