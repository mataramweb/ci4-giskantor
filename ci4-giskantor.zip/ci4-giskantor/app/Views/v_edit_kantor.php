
 <div class="row">
 <div class="col-lg-7">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Lokasi</h4>
                          
                                <div id="map" style=" height: 600px;"></div>



                            </div>
                        </div>
</div>
<div class="col-lg-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Edit Data Kantor</h4>
                              <?php 
                              $errors = session()->getFlashdata('errors');
                              if (!empty($errors)) { ?>
                              
                                <div class="alert alert-danger">
                                !!! Ada kesalahan input Data Yitu 
                                        <ul>
                                       <?php foreach ($errors as $key => $error) { ?>
                                        <li><?= esc($error) ?></li>
                                            <?php } ?>

                                        </ul>
                                    </div>

                                             <?php   }  ?>
                                <div class="basic-form">
                                  <?php echo form_open_multipart('kantor/update/'.$kantor['id']); ?>
                                        <div class="form-group">
                                            <label>Nama Kantor</label>
                                            <input type="text" name="nama_kantor" value="<?= $kantor['nama_kantor'] ?>" class="form-control input-default" placeholder="Nama Kantor">
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor Telpon</label>
                                            <input type="text" name="no_telpon" value="<?= $kantor['no_telpon'] ?>" class="form-control input-default" placeholder="Nomor Telpon">
                                        </div>
                                        <div class="form-group">
                                            <label>Alamat</label>
                                            <input type="text" name="alamat" value="<?= $kantor['alamat'] ?>" class="form-control input-default" placeholder="Alamat">
                                        </div>
                                        <div class="form-group">
                                            <label>Latidude</label>
                                            <input type="text" name="lat" id="lat"  value="<?= $kantor['lat'] ?>" class="form-control input-default" placeholder="Latitude">
                                        </div>
                                        <div class="form-group">
                                            <label>Logtitud</label>
                                            <input type="text" name="long" id="long" value="<?= $kantor['long'] ?>" class="form-control input-default" placeholder="Logtitude">
                                        </div>
                                        <div class="form-group">
                                            <label>Deskripsi</label>
                                            <input type="text" name="deskripsi"  value="<?= $kantor['deskripsi'] ?>" class="form-control input-default" placeholder="Deskripsi">
                                        </div>
                                        <div class="form-group"><br>
                                        <img src="<?= base_url('foto/' .$kantor['foto']); ?>" alt="" original-title="" width="55" height="55"><br>
                                            <input type="file" name="foto" class="form-control input-default">
                                        </div>
                                       
                                
                                        </div>
                                        <div class="input-group mb-3">
                                         <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>

                                    <?php  echo form_close(); ?>
                                </div>
                            </div>
                        </div>
</div>

 </div>
 <script>
var curLocation=[0,0];
if (curLocation[0]==0 && curLocation[1]==0){
    curLocation=[<?= $kantor['lat'] ?>,<?= $kantor['long'] ?>]
};

var map = L.map('map').setView([<?= $kantor['lat'] ?>,<?= $kantor['long'] ?>], 15);

L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {

    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
        '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
        'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    id: 'mapbox/streets-v11',
 
}).addTo(map);

map.attributionControl.setPrefix(false);
var marker = new L.marker(curLocation,{
    draggable:'true',
});

marker.on('dragend', function(event){
    var position = marker.getLatLng();
    marker.setLatLng(position,{
    draggable:'true' 
    }).bindPopup(position).update();
    $("#lat").val(position.lat);
    $("#long").val(position.lng).keyup();
    });


    
    map.addLayer(marker);

</script>