<script>
$("#lat, #long").change(function() {
        var position =[parseInt($("#lat").val()), parseInt($("#long").val())];
        marker.setLatLng(position, {
        draggable : 'true'
        }).bindPopup(position).update();
        map.panTo(position);
    });
</script>