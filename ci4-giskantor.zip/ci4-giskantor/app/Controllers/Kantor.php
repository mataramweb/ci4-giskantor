<?php namespace App\Controllers;

use App\Models\M_kantor;
use CodeIgniter\HTTP\Request;

class Kantor extends BaseController


{


    public function __construct()

    {
        helper('form');
        $this->M_kantor = new M_kantor();
    }

	public function index()
	{
		$data=[
            'judul' => 'Kantor',
            'kantor' => $this->M_kantor->get_all_data(),
			'isi'	=> 'v_kantor',
		];
        echo view('layout/v_template',$data);
        

    }
//--------------------------------------------------------------------   
    public function add()
    {
        $data=[
            'judul' => 'Tambah Kantor',
            'kantor' => $this->M_kantor->get_all_data(),
			'isi'	=> 'v_add_kantor',
		];
		echo view('layout/v_template',$data);

    }

    public function save()
    {
       $valid = $this->validate([
           'nama_kantor'      => [
                'label'       => 'nama Kantor',
                'rules'       => 'required',
                'errors'      => [
                'required'    => '{field} Wajib Diisi',
                ]                     
                ],
           'no_telpon'        => [
                'label'       => 'Nomor Telpon Kantor',
                'rules'       => 'required',
                'errors'      => [
                'required'    => '{field} Wajib Diisi',
                ]                  
                ],
            'alamat'          => [
                'label'       => 'Alamat Wajib Diisi',
                'rules'       => 'required',
                'errors'      => [
                'required'    => '{field} Wajib Diisi',
                ]                  
                ],
            'lat'            => [
                'label'      => 'Latitude',
                'rules'      => 'required',
                'errors'     => [
                'required'   => '{field} Wajib Diisi',
                 ]                  
                 ],
            'long'           => [
                'label'      => 'Longitude ',
                'rules'      => 'required',
                'errors'     => [
                'required'   => '{field} Wajib Diisi',
                 ]                  
                 ],
            'deskripsi'  => [
                'label'      => 'Deskripsi ',
                'rules'      => 'required',
                'errors'     => [
                'required'   => '{field} Wajib Diisi',
                 ]                  
                 ],
            'foto'              => [
                 'label'        => 'Foto Kantor ',
                 'rules'      => 'uploaded[foto]',
                 'errors'       => [
                    'required'   => '{field} Wajib Diisi',
                ]                  
                ],

       ]);

       if (!$valid)
       {
           session()->setFlashdata('errors',\Config\Services::validation()->getErrors());
           return redirect()->to(base_url('kantor/add'));
       } else{
            $image = $this->request->getFile('foto');
            $name = $image->getRandomName();
            $data = [
                'nama_kantor' => $this->request->getPost('nama_kantor'),
                'alamat' => $this->request->getPost('alamat'),
                'no_telpon' => $this->request->getPost('no_telpon'),
                'lat' => $this->request->getPost('lat'),
                'long' => $this->request->getPost('long'),
                'deskripsi' => $this->request->getPost('deskripsi'),
                'foto'  => $name,
            ];
            $image->move(ROOTPATH.'foto',$name);
            $this->M_kantor->insert_data($data);

            session()->setFlashdata('success','Data kantor berhasil ditambahkan');
            return redirect()->to(base_url('kantor'));

       }


    }


    public function edit($id)
    {
        $data=[
            'judul' => 'Edit Kantor',
            'kantor' => $this->M_kantor->detail($id),
			'isi'	=> 'v_edit_kantor',
		];
		echo view('layout/v_template',$data);

    }

    public function update($id)
    {
       $valid = $this->validate([
           'nama_kantor'      => [
                'label'       => 'nama Kantor',
                'rules'       => 'required',
                'errors'      => [
                'required'    => '{field} Wajib Diisi',
                ]                     
                ],
           'no_telpon'        => [
                'label'       => 'Nomor Telpon Kantor',
                'rules'       => 'required',
                'errors'      => [
                'required'    => '{field} Wajib Diisi',
                ]                  
                ],
            'alamat'          => [
                'label'       => 'Alamat Wajib Diisi',
                'rules'       => 'required',
                'errors'      => [
                'required'    => '{field} Wajib Diisi',
                ]                  
                ],
            'lat'            => [
                'label'      => 'Latitude',
                'rules'      => 'required',
                'errors'     => [
                'required'   => '{field} Wajib Diisi',
                 ]                  
                 ],
            'long'           => [
                'label'      => 'Longitude ',
                'rules'      => 'required',
                'errors'     => [
                'required'   => '{field} Wajib Diisi',
                 ]                  
                 ],
            'deskripsi'  => [
                'label'      => 'Deskripsi ',
                'rules'      => 'required',
                'errors'     => [
                'required'   => '{field} Wajib Diisi',
                 ]                  
                 ],
            'foto'              => [
                 'label'        => 'Foto Kantor ',
                 'rules'      => 'uploaded[foto]',
                 
                ],

       ]);

       if (!$valid)
       {
           session()->setFlashdata('errors',\Config\Services::validation()->getErrors());
           return redirect()->to(base_url('kantor/edit/'.$id));
       } else{
            $image = $this->request->getFile('foto');
            $name = $image->getRandomName();
            $data = [
                'nama_kantor' => $this->request->getPost('nama_kantor'),
                'alamat' => $this->request->getPost('alamat'),
                'no_telpon' => $this->request->getPost('no_telpon'),
                'lat' => $this->request->getPost('lat'),
                'long' => $this->request->getPost('long'),
                'deskripsi' => $this->request->getPost('deskripsi'),
                'foto'  => $name,
            ];
            $image->move(ROOTPATH.'foto',$name);
            $this->M_kantor->update_kantor($data, $id);

            session()->setFlashdata('success','Data kantor berhasil di Update');
            return redirect()->to(base_url('kantor'));

       }
    }

       public function delete($id)
       {
           $this->M_kantor->delete_kantor($id);
           session()->setFlashdata('success','Data kantor berhasil di Hapus');
           return redirect()->to(base_url('kantor'));
       }


    


    //--------------------------------------------------------------------
    




}
